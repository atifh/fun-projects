<div id="footer">
{include resources/navigation.md}

### Copyright

Tutorial Copyright (c) 2006-{property gwking-copyright-year} [Gary King][gwking]. All rights reserved. 
<br />
Tutorial Copyright (c) 2004-2006 [Dr. Edmund Weitz][153]. All rights reserved.   
<span id="timestamp">Last updated {today} at {now}</span>

</div>