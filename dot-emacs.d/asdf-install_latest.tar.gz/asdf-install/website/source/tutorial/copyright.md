{include resources/header.md}
{set-property title "Copyright | ASDF-Install Tutorial"}

### Copyright

Copyright (c) 2006-{property gwking-copyright-year}&nbsp;[Gary King][gwking]. All rights reserved. 
  
Copyright (c) 2004-2006 [Dr. Edmund Weitz][153]. All rights reserved.   

   [gwking]: http://www.metabang.com/
   [153]: http://www.weitz.de/

### License

Redistribution and use of this tutorial in its orginal form (HTML) or in 'derived' forms (PDF, Postscript, RTF and so forth) with or without modification, are permitted provided that the following condition is met: 

  * Redistributions must reproduce the above copyright notice, this condition and the following disclaimer in the document itself and/or other materials provided with the distribution. 

IMPORTANT: This document is provided by the author "as is" and any expressed or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed. In no event shall the author be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this documentation, even if advised of the possibility of such damage. 

<div id="footer">
{include resources/navigation.md}
 
<div id="timestamp">Last updated {today} at {now}</div>
</div>
