change log merger

styles for notes

use MD to pull docstrings instead?

Pull ASDF-Install tutorial on every page

Back links to ASDF-Install home page

- back links from parts to index
- next / previous ? (or navigation on all)
- shared footer / header
  - include
- nicer style
- colorized code

- 
- link checking
- cf. multimarkdown


"Foo 

    bar
    bar


foo"

vs.

"Foo 

    bar
    bar

foo"